#include <windows.h>
#include "resource.h"

HINSTANCE hInstance = NULL;
HWND hFly = NULL;

void CenterInsideParent(HWND hWnd)
{
	HWND hParent = GetParent(hWnd);
	RECT rcp, rcc;
	GetClientRect(hParent, &rcp);
	GetWindowRect(hWnd, &rcc);

    /* offset child rect to top left */
	rcc.bottom -= rcc.top; /* height */
	rcc.right -= rcc.left; /* width */

	/* get top-left anchor */
	rcc.left = (rcp.right - rcc.right)/2;
	rcc.top = (rcp.bottom - rcc.bottom)/2;

	/* non-child to be centered in screen coordinates, not in parent's ones */
	if (!(GetWindowLong(hWnd, GWL_STYLE) & WS_CHILD))
	{
		/* adjust anchor position */
		MapWindowPoints(hParent, GetDesktopWindow(), (LPPOINT)&rcc, 1);
	}

    //MoveWindow(hWnd, rcc.left, rcc.top, rcc.right /*width*/, rcc.bottom /*height*/, TRUE);
	SetWindowPos(hWnd, NULL, rcc.left, rcc.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

BOOL WINAPI FlyByDlgProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		switch (wp)
		{
		case IDC_BUTTON:
			CenterInsideParent(GetDlgItem(hDlg, wp));
			break;

		case IDCANCEL:
			EndDialog(hDlg, 0);
			hFly = NULL;
		}
		break;
	}

	return 0;
}

void CreateFlyBy(HWND hDlg)
{
		hFly = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAIN), hDlg, (DLGPROC)FlyByDlgProc);
		if (IsWindow(hFly))
		{
			RECT rc;
			GetWindowRect(hFly, &rc);
			int width = rc.right - rc.left - 40;
			int height = rc.bottom - rc.top - 140;
			MoveWindow(hFly, rc.left, rc.top, width, height, TRUE);
			ShowWindow(hFly, SW_SHOWNORMAL);
			UpdateWindow(hFly);
		}
		SetWindowText(hFly, "FlyBy");
		SetWindowText(GetDlgItem(hDlg, IDC_BUTTON), "Center FlyBy");
}

BOOL WINAPI DlgProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_INITDIALOG:
		CreateFlyBy(hDlg);
		return TRUE;

	case WM_COMMAND:
		switch (wp)
		{
		case IDC_BUTTON:
			if (!IsWindow(hFly))
				CreateFlyBy(hDlg);
			CenterInsideParent(hFly);
			SetFocus(hFly);
			break;

		case IDCANCEL:
			EndDialog(hDlg, 0);
		}
		break;
	}

	return 0;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR szCmd, INT nShow)
{
	hInstance = hInst;
	return DialogBox(hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DlgProc);
}