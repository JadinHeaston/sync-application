#define IDD_MAIN     100
#define IDC_BUTTON   1000
